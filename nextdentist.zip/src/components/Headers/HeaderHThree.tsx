"use client";

const HeaderHThree = ({ title }: { title: string }) => {
  return <h3 className="text-base font-bold">{title}</h3>;
};

export default HeaderHThree;
