"use client";
import ForgotPassword from "@/app/(auth)/forgot-password/ForgotPassword";

export default function ForgotPasswordPage() {
  return <ForgotPassword />;
}
