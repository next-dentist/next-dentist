"use client";
import LoginPage from "@/app/(auth)/login/LoginPage";

export default function Login() {
  return <LoginPage />;
}
