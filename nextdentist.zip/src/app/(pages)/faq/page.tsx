'use client';
import { FAQContent } from './FAQContent';

export default function FAQPage() {
  return <FAQContent />;
}
