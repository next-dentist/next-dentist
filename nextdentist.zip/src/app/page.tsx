'use client';
import HomePageClient from './HomePageClient';

const HomePage: React.FC = () => {
  return <HomePageClient />;
};

export default HomePage;
