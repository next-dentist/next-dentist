'use client';
import DentistSearchCard from '@/components/DentistSearchCard';
import { IconList } from '@/components/IconList';
import LoadingSpinner from '@/components/LoadingSpinner';
import ReviewCard from '@/components/ReviewCard';
import SearchForm from '@/components/SearchForm';
import SectionFour from '@/components/SectionFour';
import { SectionOne } from '@/components/SectionOne';
import GradientSection from '@/components/Sections/GradientSection';
import ImageSection from '@/components/Sections/ImageSection';
import WhiteSection from '@/components/Sections/WhiteSection';
import { SectionThree } from '@/components/SectionThree';
import { SectionTwo } from '@/components/SectionTwo';
import TopRightBlurButton from '@/components/TopRightBlurButton';
import TreatmentCard from '@/components/TreatmentCard';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { siteConfig } from '@/config';
import { useRecentDentists } from '@/hooks/useDentists';
import { useInfiniteTreatments } from '@/hooks/useInfiniteTreatments';
import { Dentist } from '@prisma/client';
import { motion } from 'framer-motion';
import {
  Bell,
  Calendar,
  CalendarArrowUp,
  MessageCircle,
  MoveUpRight,
  ThumbsUp,
  Timer,
  Users,
} from 'lucide-react';

import Link from 'next/link';
import React, { Suspense } from 'react';

const HomePageClient: React.FC = () => {
  // Fetch recently joined dentists
  const {
    data: recentDentists,
    isLoading: isLoadingDentists,
    isError: isDentistsError,
  } = useRecentDentists();

  // Fetch treatments
  const {
    treatments,
    isLoading: isLoadingTreatments,
    isError: isTreatmentsError,
    error: treatmentsError,
  } = useInfiniteTreatments();

  // Animation variants
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const statsVariants = {
    initial: { scale: 0.8, opacity: 0 },
    animate: {
      scale: 1,
      opacity: 1,
      transition: { type: 'spring', stiffness: 100 },
    },
  };

  // Stats for display
  const stats = [
    {
      value: '2000+',
      label: 'Dentists',
      icon: <Users className="text-primary h-8 w-8" />,
    },
    {
      value: '10,000+',
      label: 'Patients',
      icon: <Users className="text-primary h-8 w-8" />,
    },
    {
      value: '98%',
      label: 'Satisfaction',
      icon: <ThumbsUp className="text-primary h-8 w-8" />,
    },
    {
      value: '30 min',
      label: 'Avg. Response',
      icon: <Timer className="text-primary h-8 w-8" />,
    },
  ];

  return (
    <>
      <SectionOne className="from-primary/20 to-secondary/20 flex min-h-[70vh] items-center bg-gradient-to-tr">
        <div className="flex h-full w-full flex-col gap-8 text-black md:flex-row">
          <motion.div
            className="flex-1"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <WhiteSection className="flex h-full flex-col gap-6 text-black backdrop-blur-sm">
              <motion.h1
                className="text-4xl leading-tight font-bold md:text-5xl"
                {...fadeInUp}
              >
                Find Your Perfect{' '}
                <span className="text-primary">Dental Care</span> Partner
              </motion.h1>
              <motion.p
                className="text-lg opacity-80 md:pr-10"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                Book services from our network of over 2000+ qualified dentists
                and experience hassle-free appointments at your convenience.
              </motion.p>
              <Suspense fallback={<LoadingSpinner />}>
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                >
                  <SearchForm />
                </motion.div>
              </Suspense>
            </WhiteSection>
          </motion.div>

          <motion.div
            className="flex-1"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <ImageSection
              bgImage="/images/slider/section1.jpg"
              className="relative flex h-full flex-col items-stretch justify-between overflow-hidden rounded-4xl text-black"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              <TopRightBlurButton
                title="Dentists Joined"
                count="2000+"
                description="Dentists Joined"
                href="/dentists"
                position="end"
                icon
              />
              <TopRightBlurButton
                description="Brightening Smile in Hrs"
                href="#"
                position="center"
              />
            </ImageSection>
          </motion.div>

          <motion.div
            className="flex-1"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <GradientSection className="flex h-full flex-col gap-6 text-black">
              <h2 className="rounded-2xl p-4 text-2xl font-bold">
                Why Choose Us?
              </h2>
              <motion.div
                className="space-y-4"
                variants={staggerContainer}
                initial="initial"
                animate="animate"
              >
                <motion.div variants={fadeInUp}>
                  <IconList
                    icon={<Calendar color="#85A7A8" />}
                    title="Easy Appointment scheduling"
                    sufixIcon={<MoveUpRight color="#85A7A8" />}
                  />
                </motion.div>
                <motion.div variants={fadeInUp}>
                  <IconList
                    icon={<CalendarArrowUp color="#85A7A8" />}
                    title="Priority Booking"
                    sufixIcon={<MoveUpRight color="#85A7A8" />}
                  />
                </motion.div>
                <motion.div variants={fadeInUp}>
                  <IconList
                    icon={<Bell color="#85A7A8" />}
                    title="Booking Notification"
                    sufixIcon={<MoveUpRight color="#85A7A8" />}
                  />
                </motion.div>
                <motion.div variants={fadeInUp}>
                  <IconList
                    icon={<MessageCircle color="#85A7A8" />}
                    title="Easy Consultation"
                    sufixIcon={<MoveUpRight color="#85A7A8" />}
                  />
                </motion.div>
              </motion.div>
            </GradientSection>
          </motion.div>
        </div>
      </SectionOne>

      {/* Stats Section */}
      <motion.div
        className="bg-white py-16"
        initial="initial"
        whileInView="animate"
        viewport={{ once: true }}
      >
        <div className="container mx-auto">
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                variants={statsVariants}
                className="flex flex-col items-center justify-center rounded-xl bg-gray-50 p-6 shadow-sm"
              >
                {stat.icon}
                <h3 className="text-primary mt-3 text-3xl font-bold">
                  {stat.value}
                </h3>
                <p className="text-gray-600">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Recent Dentists */}
      <SectionTwo className="from-primary/10 to-secondary/10 bg-gradient-to-tr py-20">
        <motion.div
          className="flex w-full flex-col items-center justify-center gap-4 p-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold">Recently Joined Dentists</h2>
          <p className="mb-8 max-w-2xl text-center text-gray-600">
            Our network is constantly growing with qualified professionals ready
            to provide excellent dental care services.
          </p>
        </motion.div>
        <div className="flex flex-col gap-4">
          {isLoadingDentists ? (
            <div className="flex justify-center py-8">
              <LoadingSpinner size="lg" />
            </div>
          ) : isDentistsError ? (
            <div className="py-8 text-center text-red-500">
              Error loading dentists. Please try again later.
            </div>
          ) : recentDentists && recentDentists.length > 0 ? (
            <motion.div
              className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4"
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
            >
              {recentDentists.map((dentist: Dentist, index: number) => (
                <motion.div
                  key={dentist.id}
                  variants={fadeInUp}
                  custom={index}
                  transition={{ delay: index * 0.1 }}
                >
                  <DentistSearchCard dentistData={dentist} />
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <div className="py-8 text-center">
              No dentists found. Check back soon!
            </div>
          )}
        </div>
        <div className="mt-10 flex justify-center">
          <Link href="/dentists">
            <Button size="lg" className="px-8">
              View All Dentists
            </Button>
          </Link>
        </div>
      </SectionTwo>

      {/* Services Section */}
      <motion.div
        className="bg-white py-20"
        initial="initial"
        whileInView="animate"
        viewport={{ once: true }}
      >
        <div className="container mx-auto">
          <motion.div className="mb-12 text-center" variants={fadeInUp}>
            <h2 className="mb-4 text-4xl font-bold">Treatments available</h2>
            <p className="mx-auto max-w-2xl text-gray-600">
              We provide comprehensive dental services to ensure your smile is
              always at its best.
            </p>
          </motion.div>

          {isLoadingTreatments ? (
            <div className="flex justify-center py-8">
              <LoadingSpinner size="lg" />
            </div>
          ) : isTreatmentsError ? (
            <div className="py-8 text-center text-red-500">
              Error loading treatments:{' '}
              {treatmentsError?.message || 'Unknown error'}
            </div>
          ) : treatments && treatments.length > 0 ? (
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
              {treatments.slice(0, 4).map(treatment => (
                <motion.div
                  key={treatment.id}
                  variants={fadeInUp}
                  custom={treatment.id}
                  transition={{ delay: 0.1 }}
                >
                  <TreatmentCard
                    title={treatment.name || ''}
                    description={treatment.description || ''}
                    imageUrl={treatment.image || ''}
                    slug={treatment.slug || ''}
                  />
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-gray-500">
              No treatments found. Check back soon!
            </div>
          )}

          <motion.div className="mt-10 flex justify-center" variants={fadeInUp}>
            <Link href="/treatments">
              <Button size="lg" className="px-8">
                Explore All Treatments
              </Button>
            </Link>
          </motion.div>
        </div>
      </motion.div>

      {/* Reviews Section */}
      <SectionFour className="bg-gray-50 py-20">
        <motion.div
          className="flex w-full flex-col items-center justify-center gap-4 p-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold">What Our Patients Say</h2>
          <p className="mb-8 max-w-2xl text-center text-gray-600">
            Discover why thousands of patients trust us with their dental care
            needs.
          </p>
        </motion.div>
        <motion.div
          className="flex flex-col gap-8 md:flex-row"
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
        >
          {siteConfig.reviews.map((review, index) => (
            <motion.div
              key={review.id}
              variants={fadeInUp}
              custom={index}
              transition={{ delay: index * 0.1 }}
              className="flex-1"
            >
              <ReviewCard
                name={review.name}
                image={review.image}
                profession={review.profession}
                review={review.review}
              />
            </motion.div>
          ))}
        </motion.div>
      </SectionFour>

      {/* CTA Section */}
      <SectionThree className="gap-4 bg-radial from-[#bed5d8] to-[#bed5d8] py-20">
        <motion.div
          className="flex w-full flex-col items-center gap-8 md:flex-row"
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
        >
          <motion.div
            className="flex basis-1/2 flex-col gap-6"
            variants={fadeInUp}
          >
            <div className="flex flex-col gap-4 md:max-w-3/4">
              <motion.span
                className="text-primary font-medium"
                variants={fadeInUp}
              >
                Comprehensive Dental Services
              </motion.span>
              <motion.h2
                className="text-4xl leading-tight font-bold"
                variants={fadeInUp}
              >
                Your Trusted Partner for All Your Dental Needs
              </motion.h2>
              <motion.p
                className="mb-6 leading-relaxed text-gray-700"
                variants={fadeInUp}
              >
                At NextDentist Dental Clinics, we provide comprehensive dental
                services to ensure your smile is always at its best. All our
                dentists are highly trained and experienced. We use the latest
                technology and equipment to provide the best possible care.
              </motion.p>
              <motion.div variants={fadeInUp}>
                <Button size="lg" className="px-8">
                  Book an Appointment
                </Button>
              </motion.div>
            </div>
          </motion.div>
          <motion.div
            className="flex basis-1/2 flex-col gap-4"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <ImageSection
              bgImage="/images/dentist-card.jpg"
              className="relative flex h-[400px] flex-col items-stretch justify-between overflow-hidden rounded-4xl text-black"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
              <div className="flex min-h-20">&nbsp;</div>
              <TopRightBlurButton
                description="Brightening Smile in Hrs"
                href="#"
                position="center"
              />
            </ImageSection>
          </motion.div>
        </motion.div>
      </SectionThree>

      {/* Newsletter Signup */}
      <motion.div
        className="bg-white py-16"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        <div className="container mx-auto">
          <Card className="from-primary/10 to-secondary/10 mx-auto max-w-4xl border-none bg-gradient-to-r shadow-lg">
            <CardContent className="p-10">
              <motion.div className="mb-8 text-center" variants={fadeInUp}>
                <h2 className="mb-4 text-3xl font-bold">
                  Stay Updated with Dental Tips
                </h2>
                <p className="text-gray-600">
                  Subscribe to our newsletter for the latest dental care tips
                  and special offers.
                </p>
              </motion.div>

              <motion.div
                className="mx-auto flex max-w-xl flex-col gap-4 sm:flex-row"
                variants={fadeInUp}
              >
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="focus:ring-primary flex-1 rounded-lg border px-4 py-3 focus:ring-2 focus:outline-none"
                />
                <Button size="lg">Subscribe</Button>
              </motion.div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </>
  );
};

export default HomePageClient;
