"use client";
import Dashboard from "./DashBoard";

export default function DashboardPage() {
  return <Dashboard />;
}
