'use client';

import CostPageList from './CostPageList';

import React from 'react';

const CostPage: React.FC = props => {
  return <CostPageList />;
};

export default CostPage;
