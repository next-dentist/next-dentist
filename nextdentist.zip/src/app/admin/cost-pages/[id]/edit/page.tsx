'use client';

import EditCostPageClient from './EditCostPageClient';

const CostPage: React.FC = (props) => {
  return (
    <div className="w-full">
      <EditCostPageClient />
    </div>
  );
};

export default CostPage;
