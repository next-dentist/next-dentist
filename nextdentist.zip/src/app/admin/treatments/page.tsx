"use client";

import AdminTreatmentList from "./adminTreatmentList";

export default function TreatmentsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <AdminTreatmentList />
    </div>
  );
}
