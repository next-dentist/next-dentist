'use client';

import AddTreatmentClient from './AddTreatment';

export default function AddTreatmentPage() {
  return <AddTreatmentClient />;
}
