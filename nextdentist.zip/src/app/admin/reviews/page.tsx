'use client ';
import AdminReviewManager from '@/components/admin/AdminReviewManager';

export default function ReviewsPage() {
  return <AdminReviewManager />;
}
