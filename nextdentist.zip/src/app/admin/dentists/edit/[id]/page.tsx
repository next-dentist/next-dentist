import React from "react";
import EditDentistPage from "./EditDentistPage";

const EditPage: React.FC = () => {
  return <EditDentistPage />;
};

export default EditPage;
