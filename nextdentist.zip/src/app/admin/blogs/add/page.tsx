'use client';

import React from 'react';
import AddBlogPostClient from './addBlogPostClient';

const AddBlogPost: React.FC = () => {
  return <AddBlogPostClient />;
};

export default AddBlogPost;
