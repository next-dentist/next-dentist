'use client';

import React from 'react';
import AdminBlogList from './adminBlogList';
const AdminBlogs: React.FC = () => {
  return <AdminBlogList />;
};

export default AdminBlogs;
